﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : NavigationWindow , INotifyPropertyChanged
    {
        private List<UrunClass> alnanUruns1;

        public List<UrunClass> uruns { get; set; }
        public List<UrunClass> uruns2 { get; set; }
        public List<UrunClass> uruns3 { get; set; }
        public List<UrunClass> alnanUruns { get => alnanUruns1; set { alnanUruns1 = value; OnProportyChangin(); } }

        public UrunClass baxUrun { get; set; }


        public event PropertyChangedEventHandler? PropertyChanged;
       

        public void OnProportyChangin([CallerMemberName] string name = null)
        {

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        }



        byte getColor() { return (byte)Random.Shared.Next(256); }

        public MainWindow()
        {
            InitializeComponent();


            alnanUruns = new List<UrunClass>() {

                new UrunClass() { Id = "1234", Name = "Cpess", Price = 5, Date = DateTime.Now, BGColor = new SolidColorBrush(Color.FromRgb(getColor(), getColor(), getColor())) },
                new UrunClass() { Id = "1234", Name = "Cpess", Price = 5, Date = DateTime.Now, BGColor = new SolidColorBrush(Color.FromRgb(getColor(), getColor(), getColor())) },
                new UrunClass() { Id = "1234", Name = "Cpess", Price = 5, Date = DateTime.Now, BGColor = new SolidColorBrush(Color.FromRgb(getColor(), getColor(), getColor())) } 
            
            
            
            
            };

            uruns = new List<UrunClass>()
            {
               
                    
                new UrunClass() { Id = "1234" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "1111" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "1222" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "1333" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "2345" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                  
            };


            uruns2 = new List<UrunClass>()
            {


                new UrunClass() { Id = "2222" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "1134" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "6544" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "7556" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "3945" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) }

            };

            uruns3 = new List<UrunClass>()
            {


                new UrunClass() { Id = "1013" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "0459" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "4292" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "0294" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) },
                new UrunClass() { Id = "5494" , Name = "Cpess" , Price = 5 , Date = DateTime.Now , BGColor = new SolidColorBrush(Color.FromRgb(getColor(),getColor(),getColor())) }

            };





            DataContext = this;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            Button b1 = sender as Button;

           


            for (int i = 0; i < uruns.Count; i++)
            {

                if (uruns[i] == b1.Content) { baxUrun = uruns[i]; break; }

            }


            for (int i = 0; i < uruns2.Count; i++)
            {

                if (uruns2[i] == b1.Content) { baxUrun = uruns2[i]; break; }

            }

            for (int i = 0; i < uruns3.Count; i++)
            {

                if (uruns3[i] == b1.Content) { baxUrun = uruns3[i]; break; }

            }

           

            this.NavigationService.Navigate(new EtrafliUrun()); 

        }

        private void Button_Click___(object sender, RoutedEventArgs e)
        {

            Button b1  = sender as Button;


            UrunClass alUrun = new UrunClass();

            for (int i = 0; i < uruns.Count; i++)
            {

                if (uruns[i].Id == b1.Content) { alUrun = uruns[i]; break; }

            }


            for (int i = 0; i < uruns2.Count; i++)
            {

                if (uruns2[i].Id == b1.Content) { alUrun = uruns2[i]; break; }

            }

            for (int i = 0; i < uruns3.Count; i++)
            {

                if (uruns3[i].Id == b1.Content) { alUrun = uruns3[i]; break; }

            }

           
            

            alnanUruns.Add(alUrun);

            OnProportyChangin(nameof(alnanUruns));

            this.Refresh();
        }
    }
}
