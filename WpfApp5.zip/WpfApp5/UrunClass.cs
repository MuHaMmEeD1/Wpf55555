﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace WpfApp5
{
    public class UrunClass : INotifyPropertyChanged
    {
        private string ıd;
        private string name;
        private double price;
        private DateTime date;
        private SolidColorBrush bGColor;

        public string Id { get => ıd; set { ıd = value; OnProportyChangin(); } }
        public string Name { get => name; set { name = value; OnProportyChangin(); } }
        public double Price { get => price; set { price = value; OnProportyChangin(); } }
        public DateTime Date { get => date; set { date = value; OnProportyChangin(); } }
        public SolidColorBrush BGColor { get => bGColor; set { bGColor = value; OnProportyChangin(); } }


        public event PropertyChangedEventHandler? PropertyChanged;


        public void OnProportyChangin([CallerMemberName] string name = null)
        {

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        }

        public override string ToString()
        {
            return $"Id {Id}\nName {Name}\nPrice {Price}\nDate {Date.ToShortDateString()}"; 
            
        }
    }
}
